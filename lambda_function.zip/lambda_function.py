import json
import boto3

client = boto3.client('athena')

table = "pesquisas"
database = "desafio_maxmilhas"
workgroup = "maxmilhas_desafio"
query = 'SELECT DISTINCT airport_to,SUM(buscou) AS total_buscas,SUM(comprou) AS total_compras FROM "%s"."%s" WHERE comprou <> 0 AND buscou <> 0 GROUP BY airport_to;' % (database,table)

athena_result_bucket = "s3://projeto-maxmilhas-desafio/outputs/"

def lambda_handler(event, context):
    response = client.start_query_execution(
        QueryString=query,
        QueryExecutionContext={
            'Database': database
        },
        ResultConfiguration={
            'OutputLocation': athena_result_bucket,
        },
        WorkGroup=workgroup
    )
    return {
        'statusCode': 200,
        'body': json.dumps(response)
    }
